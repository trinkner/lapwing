

stylesheetBase = """
            QWidget {
                background: rgb(85, 87, 89);
                color: rgb(223, 228, 235)
            }
            QComboBox {
                border: 2px;
                outline: 2px;
                border-radius: 2px;
                padding: 1px 18px 1px 3px;
                min-width: 3em;
                color: rgb(223, 228, 235)
            }            
            QListWidget:item:selected {
                background: rgb(56,114,189)
            }
            QListWidget:item:!active {
                color: silver
            }
            QLabel {
                border: none
            }
            QTabWidget::pane {
                border: 1px solid silver
            }
            QTabWidget::tab-bar:top {
                top: 1px
            }
            QTabWidget::tab-bar:bottom {
                bottom: 1px
            }
            QTabWidget::tab-bar:left {
                right: 1px
            }
            QTabWidget::tab-bar:right {
                left: 1px
            }
            QTabBar::tab {
                border: 1px solid silver;
                min-width: 7ex;
                padding: 3px
            }
            QTabBar::tab:selected {
                background: rgb(80,80,80);
                color: white
            }
            QLineEdit {
                border: 1px solid silver;
                color:  rgb(56,114,189)
            }
            QHeaderView::section {
                background-color: rgb(50,50,50);
                color: silver;
                padding-left: 4px;
                border: none
            }
            QCheckBox:indicator:unchecked {
                background-color: white;
            }
            QCheckBox:indicator:checked {
                background-color: blue;
            }
            QPushButton {
                background-color: rgb(80,80,80);
                border-radius: 1px;
                padding: 5px;
                min-width: 5em;
                outline: 1px
            }
            QScrollBar:vertical {
                background: rgb(56,114,189);
                width: 10px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar:vertical {
                background: rgb(80,80,80);
                width: 10px;
                margin: 0px 0px 0px 0px;
                border: none
            }
            QScrollBar:horizontal {
                background: rgb(80,80,80);
                width: 10px;
                margin: 0px 0px 0px 0px;
                border: none
            }"""
