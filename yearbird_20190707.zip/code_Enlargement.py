import form_Enlargement
import code_Filter

import os
from math import floor

import piexif

from PyQt5.QtGui import (
    QPixmap,
    QPainter
    )
    
from PyQt5.QtCore import (
    Qt,
    pyqtSignal,
    QTimer
    )
    
from PyQt5.QtWidgets import (
    QMdiSubWindow,
    QGraphicsView,
    QGraphicsScene,
    QMessageBox,
    QMenu,
    QLabel
    )
   

class Enlargement(QMdiSubWindow, form_Enlargement.Ui_frmEnlargement):
    
    # create "resized" as a signal that the window can emit
    # we respond to this signal with the form's resizeMe method below
    resized = pyqtSignal() 
    
    class MyGraphicsView(QGraphicsView):
        
        def __init__(self):
            QGraphicsView.__init__(self)
            self.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
            self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
            self.setDragMode(QGraphicsView.ScrollHandDrag)
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            
            
        def wheelEvent(self,event):        
            adj = 1 + event.angleDelta().y()/120 * 0.1
            self.scale(adj, adj)
            
            
        def contextMenuEvent(self, event):
    
            menu = QMenu(self)
            menu.setStyleSheet("color:silver; background-color: #343333;")
            
            actionFitToWindow = menu.addAction("Fit to window (F)")
            actionShowNextPhoto = menu.addAction("Next photo (Space bar)")
            actionShowPreviousPhoto = menu.addAction("Previous photo (Backspace)")
            actionToggleCameraDetails = menu.addAction("Show/Hide details (F9)")
            actionToggleFullScreen = menu.addAction("Toggle full screen (F11)")
            menu.addSeparator()
            actionDetachFile = menu.addAction("Detach photo from Yearbird")
            menu.addSeparator()
            actionDeleteFile = menu.addAction("Delete photo from file system")
            
            action = menu.exec_(self.mapToGlobal(event.pos()))

            if action == actionFitToWindow:
                self.parent().fitEnlargement()

            if action == actionShowNextPhoto:
                self.parent().showNextPhoto()
            
            if action == actionShowPreviousPhoto:
                self.parent().showPreviousPhoto()

            if action == actionToggleCameraDetails:
                self.parent().toggleCameraDetails()
                
            if action == actionToggleFullScreen:
                self.parent().toggleFullScreen()

            if action == actionDeleteFile:
                self.parent().deleteFile()
                
            if action == actionDetachFile:
                self.parent().detachFile()                
                              
    
    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        self.resized.connect(self.resizeMe)        
        self.mdiParent = ""
        self.photoList = []
        self.currentIndex = 0
        self.pixmapEnlargement = QPixmap()
        self.cameraDetails = QLabel()
        self.layout().addWidget(self.cameraDetails)
        self.layout().setDirection(1)
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().setSpacing(0)

        self.cameraDetails.setStyleSheet("color:silver; background-color: #343333; padding: 3px")                
        self.cameraDetails.setVisible(False)


    def resizeEvent(self, event):
        #routine to handle window resize event        
        self.resized.emit()
        return super(self.__class__, self).resizeEvent(event)
        
            
    def resizeMe(self):
        
        QTimer.singleShot(5, self.fitEnlargement)
        
        
    def scaleMe(self):
        
        return
        

    def keyPressEvent(self, e):

        # F key is pressed. Re-display the currentEnlargement to fit the screen
        if e.key() == Qt.Key_F:   
            self.fitEnlargement()
            
        # Backspace key is pressed, so show previous image as enlargement     
        if e.key() == Qt.Key_Backspace:
            self.showPreviousPhoto()

        # Space bar is pressed, so show next image as enlargement     
        if e.key() == Qt.Key_Space:
            self.showNextPhoto()

        # F9 is pressed, so toggle display of camera details 
        if e.key() == Qt.Key_F9:
            self.toggleCameraDetails()

        # F11 is pressed, so toggle display of camera details 
        if e.key() == Qt.Key_F11:
            self.toggleFullScreen()

        # Esc is pressed, so exit full screen mode, if we're in it 
        if e.key() == Qt.Key_Escape and self.mdiParent.mdiParent.statusBar.isVisible() is False:
            self.toggleFullScreen()
                        

    def showPreviousPhoto(self):
            
        if self.currentIndex > 0:
            self.currentIndex = self.currentIndex - 1            
        
        if self.currentIndex >= 0:                
            self.changeEnlargement()
    
    
    def showNextPhoto(self):
                
        if self.currentIndex < len(self.photoList) - 1:            
            self.currentIndex += 1            
            self.changeEnlargement()

                                  
    def fillEnlargement(self): 
        
        # routine uses self.currentIndex to fill the right photo
        self.pixmapEnlargement = QPixmap(self.photoList[self.currentIndex][0]["fileName"])                 
            
        self.sceneEnlargement= QGraphicsScene()
        # save the item ID of the pixmap so we can replace the pixmap photo easily later
        self.itemPixmap = self.sceneEnlargement.addPixmap(self.pixmapEnlargement)

        self.viewEnlargement = self.MyGraphicsView()                
        self.viewEnlargement.setScene(self.sceneEnlargement)
        self.viewEnlargement.setStyleSheet("QWidget{ background-color: #343333;}")
        
        # add viewEnlargementto the default layout of the form
        self.layout().addWidget(self.viewEnlargement)
        
        self.setCameraDetails()               
                       
        self.setPhotoTitle()  
                   
        QTimer.singleShot(10, self.fitEnlargement)   


    def changeEnlargement(self):
        
        self.pixmapEnlargement = QPixmap(self.photoList[self.currentIndex][0]["fileName"])                 

        self.itemPixmap.setPixmap(self.pixmapEnlargement)
        
        self.setCameraDetails()
        
        self.setPhotoTitle()
        
        QTimer.singleShot(10, self.fitEnlargement)   
        

    def fitEnlargement(self):
        
        # scale the view to fit the photo, edge to edge
        self.viewEnlargement.setSceneRect(0, 0, self.pixmapEnlargement.width(), self.pixmapEnlargement.height())
        self.viewEnlargement.fitInView(self.viewEnlargement.sceneRect(), Qt.KeepAspectRatio)
        
        
    def setPhotoTitle(self):
        
        # display the file name in the window title bar
        basename = os.path.basename(self.photoList[self.currentIndex][0]["fileName"])
        self.setWindowTitle(basename) 
        
        
    def toggleCameraDetails(self):
        
        # toggle visibility of cameraDetails
        if self.cameraDetails.isVisible() is True:
            self.cameraDetails.setVisible(False)
        else:
            self.cameraDetails.setVisible(True)
            
        QTimer.singleShot(10, self.fitEnlargement)   


    def detachFile(self):
        
        # remove photo from database, but don't delete it from file system
        msgText = "Detach \n\n" + self.photoList[self.currentIndex][0]["fileName"] + "\n\n from Yearbird?"
        msgText = msgText + "\n\n(File will NOT be deleted from file system)"
        
        msg = QMessageBox()
        msg.setText(msgText)
        msg.setWindowTitle("Detach photo?")
        msg.setStandardButtons(QMessageBox.No | QMessageBox.Yes)
        buttonClicked = msg.exec_()
        
        if buttonClicked == QMessageBox.Yes:
                
            # remove photo from database
            currentPhoto = self.photoList[self.currentIndex][0]["fileName"]
            photoCommonName = self.photoList[self.currentIndex][1]["commonName"]
            photoLocation = self.photoList[self.currentIndex][1]["location"] 
            
            self.mdiParent.mdiParent.db.removePhotoFromDatabase(photoLocation, "", "", photoCommonName, currentPhoto)             
            
            # remove photo from current window's photo list
            self.photoList.remove(self.photoList[self.currentIndex])

            # refresh display of parent photo list
            self.mdiParent.FillPhotos(self.mdiParent.filter)
            
            # advance display to next photo
            if len(self.photoList) == 0:
                self.close()
                
            if self.currentIndex < len(self.photoList):                        
                self.changeEnlargement()            
            
            else:
                self.currentIndex -= 1
                self.changeEnlargement()
                                        
            # set flag for requiring photo file save
            self.mdiParent.mdiParent.db.photosNeedSaving = True

            
    def deleteFile(self):
        
        # remove photo from database, but don't delete it from file system
        msgText = "Permanently delete \n\n" + self.photoList[self.currentIndex][0]["fileName"] + "\n\n from Yearbird and the file system?"
        
        msg = QMessageBox()
        msg.setText(msgText)
        msg.setWindowTitle("Permanently delete photo?")
        msg.setStandardButtons(QMessageBox.No | QMessageBox.Yes)
        buttonClicked = msg.exec_()
        
        if buttonClicked == QMessageBox.Yes:
                
            # remove photo from database
            currentPhoto = self.photoList[self.currentIndex][0]["fileName"]
            photoCommonName = self.photoList[self.currentIndex][1]["commonName"]
            photoLocation = self.photoList[self.currentIndex][1]["location"] 
            
            self.mdiParent.mdiParent.db.removePhotoFromDatabase(photoLocation, "", "", photoCommonName, currentPhoto)             
            
            # remove photo from current window's photo list
            self.photoList.remove(self.photoList[self.currentIndex])

            # advance display to next photo
            if len(self.photoList) == 0:
                self.close()
                
            if self.currentIndex < len(self.photoList):                        
                self.changeEnlargement()            
            
            else:
                self.currentIndex -= 1
                self.changeEnlargement()
                                        
            # set flag for requiring photo file save
            self.mdiParent.mdiParent.db.photosNeedSaving = True  
            
            # delete file from file system
            if os.path.isfile(currentPhoto):
                try:
                    os.remove(currentPhoto)
                except:
                    pass

            # refresh display of parent photo list
            self.mdiParent.FillPhotos(self.mdiParent.filter)
                          
            
    def toggleFullScreen(self):
        
        # toggle visibility of filter and menu bar
        if self.mdiParent.mdiParent.dckFilter.isVisible() is True:
            
            self.mdiParent.mdiParent.dckFilter.setVisible(False)
            self.mdiParent.mdiParent.dckPhotoFilter.setVisible(False)
            self.mdiParent.mdiParent.menuBar.setVisible(False)
            self.mdiParent.mdiParent.toolBar.setVisible(False)
            self.mdiParent.mdiParent.statusBar.setVisible(False)
            self.setWindowFlags(Qt.FramelessWindowHint)
            self.mdiParent.mdiParent.showFullScreen()
            self.showMaximized()
            
        else:
            
            self.mdiParent.mdiParent.dckFilter.setVisible(True)
            self.mdiParent.mdiParent.dckPhotoFilter.setVisible(True)
            self.mdiParent.mdiParent.menuBar.setVisible(True)
            self.mdiParent.mdiParent.toolBar.setVisible(True)
            self.mdiParent.mdiParent.statusBar.setVisible(True)
            self.mdiParent.mdiParent.showNormal()
            self.mdiParent.mdiParent.showMaximized()
            self.setWindowFlags(Qt.SubWindow)
            self.showNormal()
            
        QTimer.singleShot(10, self.fitEnlargement)   

            
    def setCameraDetails(self):
        
        currentPhoto = self.photoList[self.currentIndex][0]["fileName"]
        
        photoCommonName = self.photoList[self.currentIndex][1]["commonName"]
        photoScientificName = self.photoList[self.currentIndex][1]["scientificName"]
        photoLocation = self.photoList[self.currentIndex][1]["location"]
        
        # get EXIF data
        
        try:
            exif_dict = piexif.load(currentPhoto)
        except:
            exif_dict = ""
        
        # get photo date from EXIF
        try:
            photoDateTime = exif_dict["Exif"][piexif.ExifIFD.DateTimeOriginal].decode("utf-8")
            
            #parse EXIF data for date/time components
            photoExifDate = photoDateTime[0:4] + "-" + photoDateTime[5:7] + "-" + photoDateTime[8:10]
            photoExifTime = photoDateTime[11:13] + ":" + photoDateTime[14:16]
        except:
            photoExifDate = "Date unknown"
            photoExifTime = "Time unknown"
            
        try:
            photoExifModel = exif_dict["0th"][piexif.ImageIFD.Model].decode("utf-8")
        except:
            photoExifModel = ""
        try:
            photoExifLensModel = exif_dict["Exif"][piexif.ExifIFD.LensModel].decode("utf-8")
        except:
            photoExifLensModel = ""
        
        try:        
            photoExifExposureTime = exif_dict["Exif"][piexif.ExifIFD.ExposureTime]
            photoExifExposureTime = "1/" + str(floor(photoExifExposureTime[1] / photoExifExposureTime[0])) + " sec"
        except:
            photoExifExposureTime = ""

        try:
            photoExifAperture = exif_dict["Exif"][piexif.ExifIFD.FNumber]
            photoExifAperture = round(photoExifAperture[0] / photoExifAperture[1], 1)
        except:
            photoExifAperture = ""
            
        try:
            photoExifISO = exif_dict["Exif"][piexif.ExifIFD.ISOSpeedRatings]
        except:
            photoExifISO = ""
        
        try:
            photoExifFocalLength = exif_dict["Exif"][piexif.ExifIFD.FocalLength]
            photoExifFocalLength = floor(photoExifFocalLength[0] / photoExifFocalLength[1])
            photoExifFocalLength = str(photoExifFocalLength) + " mm"
            
        except:
            photoExifFocalLength = ""
            
        detailsText = photoCommonName + "\n"
        detailsText = detailsText + photoScientificName + "\n"
        detailsText = detailsText + "\n"
        detailsText = detailsText + photoLocation + "\n"
        detailsText = detailsText + "Date: " + photoExifDate + "\n"
        detailsText = detailsText + "Time: " + photoExifTime + "\n"
        detailsText = detailsText + "\n"
        detailsText = detailsText + "Camera: " + photoExifModel + "\n"
        detailsText = detailsText + "Lens: " + photoExifLensModel + "\n"
        detailsText = detailsText + "Focal Length: " + str(photoExifFocalLength) + "\n"
        detailsText = detailsText + "Exposure: " + str(photoExifExposureTime) + "\n"
        detailsText = detailsText + "Aperture: " + str(photoExifAperture) + "\n"
        detailsText = detailsText + "ISO: " + str(photoExifISO)

        self.cameraDetails.setText(detailsText)
        
        